import React from 'react';
import { createRoot } from 'react-dom/client';
import aldiLogo from './aldi-logo.jpg';

// cara1 createElement
// const heading = React.createElement('h1', {className:'pala'}, 'Biodata Saya');
// const listItem1 = React.createElement('li', null, 'Nama: Aldi Akbar');
// const listItem2 = React.createElement('li', null, 'Umur: 26 Tahun');
// const listItem3 = React.createElement('li', null, 'Youtube: AldiGaming');
// const ulul = React.createElement('ul', {id: 'uhuy'}, [listItem1,listItem2,listItem3]);
// const container = React.createElement('div', {className:'contain'}, [heading, ulul]);

// const root = createRoot(document.getElementById('root'));
// root.render(container);

// cara2 JSX
const element = (
  <div className="contain">
    <h1 className="pala">Biodata Saya</h1>
    <ul id="uhuy">
      <li>Nama: Aldi Akbar</li>
      <li>Umur: 26 Tahun</li>
      <li>Youtube: Aldi Gaming</li>
      <img src={aldiLogo} alt="Aldi Logo" />
    </ul>
  </div>
);

const root = createRoot(document.getElementById('root'));
root.render(element);
